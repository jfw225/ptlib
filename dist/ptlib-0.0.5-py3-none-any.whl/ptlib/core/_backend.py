# internal server address
SERVER_ADDRESS = ("localhost", 64530)
